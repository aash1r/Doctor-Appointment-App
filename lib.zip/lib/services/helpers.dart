import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Helpers {
  static final TextStyle colour =
      GoogleFonts.poppins(color: Colors.black, fontSize: 12);
}
